## Website: [lain.quest](https://lain.quest)

### Preview: 
<img src="https://user-images.githubusercontent.com/106390820/210182531-ad767f8b-a3eb-4ea7-a5ff-a5498cb057d4.png" alt="Preview image" width="1280">
